# InputfiledUID
ProcessWire - Adds additional option to Fieldtype Text to verify input as a UID.

# Changelog

Ironman (1.0)
* Initial release
